import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, Button, Form, Row, Col, Alert } from 'react-bootstrap';

// PedidoItensForm agora gerencia Adição, Edição e Exclusão
const PedidoItensForm = ({ pedidoId, initialItens, onItemUpdated }) => { 
    const [itens, setItens] = useState(initialItens || []); 
    const [produtos, setProdutos] = useState([]);
    const [editingId, setEditingId] = useState(null);
    const [editData, setEditData] = useState({});

    const [novoItem, setNovoItem] = useState({
        produtoId: '',
        quantidade: '',
        precoUnitario: ''
    });

    // Efeitos
    useEffect(() => {
        fetchProdutos();
    }, []);
    
    useEffect(() => {
    if (pedidoId) {
        fetchItens(pedidoId); // Usa a nova função de busca
    }
}, [pedidoId]); // Dispara sempre que o ID do pedido muda

    //buscar itens
    const fetchItens = async (id) => {
    try {
        const response = await axios.get(`http://localhost:5000/api/PedidoItens/${id}`);
        setItens(response.data); // Atualiza o estado 'itens' com a nova lista
    } catch (error) {
        console.error('Erro ao buscar itens do pedido:', error);
    }
};

    // Busca de Produtos
    const fetchProdutos = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/Produto');
            setProdutos(response.data);
        } catch (error) {
            console.error('Erro ao buscar produtos:', error);
        }
    };

    // --- Lógica de Adição (Mantida) ---
    const handleAddItem = async (e) => {
    e.preventDefault();
    try {
        const itemParaAdicionar = {
            ...novoItem,
            pedidoId: pedidoId,
            quantidade: parseInt(novoItem.quantidade),
            precoUnitario: parseFloat(novoItem.precoUnitario)
        };
        
        // 1. Envia o novo item para o backend
        await axios.post('http://localhost:5000/api/PedidoItens/', itemParaAdicionar);
        
        // 2. PASSO CRUCIAL: Recarrega a lista completa de itens
        await fetchItens(pedidoId);
        
        // 3. Limpa o formulário de adição
        setNovoItem({ produtoId: '', quantidade: '', precoUnitario: '' });
        
        // 4. Opcional: Notifica o pai (se o pai precisar atualizar, por exemplo, o Valor Total)
        if (onItemUpdated) {
            onItemUpdated(); 
        }

        // Remova a chamada 'onItemUpdated()' duplicada
        
    } catch (error) {
        console.error('Erro ao adicionar item:', error);
    }
};

    // --- Lógica de Exclusão (NOVA) ---
   const handleDeleteItem = async (itemId) => {
    if (window.confirm('Tem certeza que deseja excluir este item?')) {
        try {
            // Endpoint DELETE /api/PedidoItens/{id}
            await axios.delete(`http://localhost:5000/api/PedidoItens/${itemId}`);
            
            // PASSO CRUCIAL: ATUALIZA O ESTADO LOCAL
            // Filtra o array de 'itens', criando um novo array sem o item excluído.
            setItens(prevItens => prevItens.filter(item => item.id !== itemId));

            // Notifica o componente pai (Pedidos.js) para recarregar o pedido completo,
            // caso o valor total ou outros dados precisem ser atualizados.
            if (onItemUpdated) {
                onItemUpdated();
            }
            
            // Remova qualquer chamada 'onItemUpdated()' duplicada aqui.

        } catch (error) {
            console.error('Erro ao excluir item:', error);
            // Opcional: Mostrar uma mensagem de erro para o usuário
        }
    }
};

    // --- Lógica de Edição (NOVA) ---
    const handleStartEdit = (item) => {
        setEditingId(item.id);
        setEditData({ 
            quantidade: item.quantidade.toString(),
            precoUnitario: item.precoUnitario.toFixed(2).toString(),
            produtoId: item.produtoId // Mantém o produto para envio
        });
    };

    const handleChangeEdit = (e) => {
        const { name, value } = e.target;
        setEditData(prev => ({ ...prev, [name]: value }));
    };

    const handleSaveEdit = async (itemId) => {
    try {
        const itemOriginal = itens.find(i => i.id === itemId);

        const itemParaSalvar = {
            // Inclui todas as propriedades necessárias do item original
            ...itemOriginal, 
            // Atualiza as propriedades editáveis
            quantidade: parseInt(editData.quantidade),
            precoUnitario: parseFloat(editData.precoUnitario),
            
            // Garante que o PedidoId seja enviado, caso seu PUT exija
            pedidoId: pedidoId 
        };

        // Endpoint PUT /api/PedidoItens/{id}
        await axios.put(`http://localhost:5000/api/PedidoItens/${itemId}`, itemParaSalvar);
        
        // PASSO CRUCIAL: Atualiza o estado 'itens' localmente.
        // Isso mapeia o array e substitui APENAS o item editado.
        setItens(prevItens => 
            prevItens.map(item => 
                item.id === itemId ? itemParaSalvar : item
            )
        );
        
        // Remove a chamada duplicada e mantém apenas uma:
        if (onItemUpdated) {
            onItemUpdated(); // Notifica o componente pai para atualizar o Valor Total.
        }

        setEditingId(null); // Sai do modo de edição
        setEditData({});

    } catch (error) {
        console.error('Erro ao salvar item:', error);
    }
};
    
    // --- Funções Auxiliares ---
    const getProdutoNome = (produtoId) => {
        const produto = produtos.find(p => p.id === produtoId);
        return produto ? produto.nome : 'Produto não encontrado';
    };

    if (!pedidoId) {
        return <Alert variant="warning">Selecione um pedido para gerenciar os itens.</Alert>;
    }
    
    return (
        <div>
            <h4>Itens do Pedido</h4>

            {itens.length > 0 ? (
                <Table striped bordered hover size="sm">
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th style={{ width: '15%' }}>Quantidade</th>
                            <th style={{ width: '15%' }}>Preço Unitário</th>
                            <th style={{ width: '15%' }}>Total</th>
                            <th style={{ width: '20%' }}>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        {itens.map(item => (
                            <tr key={item.id}>
                                <td>{getProdutoNome(item.produtoId)}</td>
                                {/* Coluna Quantidade (Editável) */}
                                <td>
                                    {editingId === item.id ? (
                                        <Form.Control 
                                            type="number" 
                                            name="quantidade"
                                            value={editData.quantidade} 
                                            onChange={handleChangeEdit}
                                            min="1"
                                        />
                                    ) : (
                                        item.quantidade
                                    )}
                                </td>
                                {/* Coluna Preço Unitário (Editável) */}
                                <td>
                                    {editingId === item.id ? (
                                        <Form.Control 
                                            type="number" 
                                            name="precoUnitario"
                                            step="0.01" 
                                            value={editData.precoUnitario} 
                                            onChange={handleChangeEdit}
                                            min="0.01"
                                        />
                                    ) : (
                                        `R$ ${item.precoUnitario.toFixed(2)}`
                                    )}
                                </td>
                                
                                <td>R$ {(item.quantidade * item.precoUnitario).toFixed(2)}</td>
                                
                                {/* Coluna Ações (Edição e Exclusão) */}
                                <td>
                                    {editingId === item.id ? (
                                        <Button variant="success" size="sm" onClick={() => handleSaveEdit(item.id)} className="me-2">
                                            Salvar
                                        </Button>
                                    ) : (
                                        <Button variant="warning" size="sm" onClick={() => handleStartEdit(item)} className="me-2">
                                            Editar
                                        </Button>
                                    )}
                                    <Button variant="danger" size="sm" onClick={() => handleDeleteItem(item.id)}>
                                        Excluir
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            ) : (
                <Alert variant="info">Nenhum item adicionado a este pedido.</Alert>
            )}

            <hr />
            {/* Formulário de Adição (Mantido) */}
            <h5>Adicionar Novo Item</h5>
            <Form onSubmit={handleAddItem}>
                <Row>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Produto</Form.Label>
                            <Form.Control as="select" value={novoItem.produtoId} onChange={(e) => setNovoItem({ ...novoItem, produtoId: e.target.value })}>
                                <option value="">Selecione um produto</option>
                                {produtos.map(p => (
                                    <option key={p.id} value={p.id}>{p.nome}</option>
                                ))}
                            </Form.Control>
                        </Form.Group>
                    </Col>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Quantidade</Form.Label>
                            <Form.Control type="number" value={novoItem.quantidade} onChange={(e) => setNovoItem({ ...novoItem, quantidade: e.target.value })} min="1" />
                        </Form.Group>
                    </Col>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Preço Unitário</Form.Label>
                            <Form.Control type="number" step="0.01" value={novoItem.precoUnitario} onChange={(e) => setNovoItem({ ...novoItem, precoUnitario: e.target.value })} min="0.01" />
                        </Form.Group>
                    </Col>
                    <Col className="d-flex align-items-end">
                        <Button variant="primary" type="submit">Adicionar</Button>
                    </Col>
                </Row>
            </Form>
        </div>
    );
};

export default PedidoItensForm;