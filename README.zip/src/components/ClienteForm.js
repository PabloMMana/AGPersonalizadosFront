import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Form, Button, Modal, Alert } from 'react-bootstrap';

const API_URL = 'http://localhost:5000/api/clientes';

const ClienteForm = ({ show, handleClose, clienteParaEditar, onSaveSuccess }) => {
    // Determina se o formulário está em modo de edição (se houver um objeto para editar)
    const isEditing = !!clienteParaEditar;
    
    const [formData, setFormData] = useState({
        nome: '',
        email: '',
        endereco: '',
        telefone: ''
    });
    
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    // Efeito para carregar dados de edição ou limpar para adição
    // Este efeito é ativado quando o modal é aberto ou quando o clienteParaEditar muda
    useEffect(() => {
        if (show) {
            setError('');
            if (isEditing && clienteParaEditar) {
                // Modo Edição: Preenche o formulário com os dados do cliente
                setFormData({
                    nome: clienteParaEditar.nome,
                    email: clienteParaEditar.email,
                    endereco: clienteParaEditar.endereco || '', 
                    telefone: clienteParaEditar.telefone || ''
                });
            } else {
                // Modo Adição: Limpa o formulário
                setFormData({ nome: '', email: '', endereco: '', telefone: '' });
            }
        }
    }, [show, isEditing, clienteParaEditar]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        setError(''); // Limpa o erro ao digitar
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        
        // Validação básica
        if (!formData.nome || !formData.email) {
            setError("Os campos Nome e Email são obrigatórios.");
            setLoading(false);
            return;
        }

        try {
            if (isEditing) {
                // Requisição PUT para Edição
                const url = `${API_URL}/${clienteParaEditar.id}`;
                await axios.put(url, formData);
            } else {
                // Requisição POST para Adição
                await axios.post(API_URL, formData);
            }
            
            onSaveSuccess(); // Notifica o componente pai (Clientes.js) para recarregar a lista
            handleClose(); // Fecha o modal
            
        } catch (err) {
            console.error('Erro ao salvar cliente:', err.response || err);
            // Tenta exibir a mensagem de erro do backend se disponível
            const serverMessage = err.response?.data?.message || 'Erro ao salvar o cliente. Tente novamente.';
            setError(serverMessage);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>{isEditing ? 'Editar Cliente' : 'Novo Cliente'}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                {error && <Alert variant="danger">{error}</Alert>}
                <Form onSubmit={handleSubmit}>
                    
                    {/* Campo Nome */}
                    <Form.Group className="mb-3" controlId="formNome">
                        <Form.Label>Nome</Form.Label>
                        <Form.Control type="text" name="nome" value={formData.nome} onChange={handleChange} required />
                    </Form.Group>
                    
                    {/* Campo Email */}
                    <Form.Group className="mb-3" controlId="formEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control type="email" name="email" value={formData.email} onChange={handleChange} required />
                    </Form.Group>

                    {/* Campo Endereço */}
                    <Form.Group className="mb-3" controlId="formEndereco">
                        <Form.Label>Endereço</Form.Label>
                        <Form.Control type="text" name="endereco" value={formData.endereco} onChange={handleChange} />
                    </Form.Group>
                    
                    {/* Campo Telefone */}
                    <Form.Group className="mb-3" controlId="formTelefone">
                        <Form.Label>Telefone</Form.Label>
                        <Form.Control type="text" name="telefone" value={formData.telefone} onChange={handleChange} />
                    </Form.Group>
                    
                    <div className="d-flex justify-content-end mt-4">
                        <Button variant="secondary" onClick={handleClose} className="me-2">
                            Cancelar
                        </Button>
                        <Button variant="primary" type="submit" disabled={loading}>
                            {loading ? 'Salvando...' : 'Salvar'}
                        </Button>
                    </div>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

export default ClienteForm;